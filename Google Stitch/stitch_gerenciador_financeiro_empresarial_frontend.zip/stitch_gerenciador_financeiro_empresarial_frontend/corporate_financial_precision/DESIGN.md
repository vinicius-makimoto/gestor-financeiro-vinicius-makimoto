---
name: Corporate Financial Precision
colors:
  surface: '#f8fafb'
  surface-dim: '#d8dadb'
  surface-bright: '#f8fafb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f5'
  surface-container: '#eceeef'
  surface-container-high: '#e6e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3f484d'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#eff1f2'
  outline: '#70787d'
  outline-variant: '#bfc8cd'
  surface-tint: '#0b6682'
  primary: '#005269'
  on-primary: '#ffffff'
  primary-container: '#166b87'
  on-primary-container: '#b6e7ff'
  inverse-primary: '#89d0ef'
  secondary: '#4c6079'
  on-secondary: '#ffffff'
  secondary-container: '#cde1ff'
  on-secondary-container: '#50647e'
  tertiary: '#434d4f'
  on-tertiary: '#ffffff'
  tertiary-container: '#5b6567'
  on-tertiary-container: '#d8e2e4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bde9ff'
  primary-fixed-dim: '#89d0ef'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#004d64'
  secondary-fixed: '#d2e4ff'
  secondary-fixed-dim: '#b4c8e6'
  on-secondary-fixed: '#061c33'
  on-secondary-fixed-variant: '#344861'
  tertiary-fixed: '#dae4e6'
  tertiary-fixed-dim: '#bec8ca'
  on-tertiary-fixed: '#141d1f'
  on-tertiary-fixed-variant: '#3f484a'
  background: '#f8fafb'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a sober, highly professional aesthetic tailored for corporate and enterprise financial management. It prioritizes clarity, data legibility, and trustworthy authority over decorative excess. The visual tone aligns with modern corporate clarity, blending crisp structural discipline with warm ergonomic readability.

Target users include financial directors, controllers, enterprise owners, and accountants who parse dense tables, multi-account statements, cash flows, and fiscal forecasts daily. The visual emotional response must inspire confidence, calculated composure, and complete certainty in transaction states.

## Colors

The palette relies on deliberate contrast hierarchies to separate structural content from actionable financial data:

- **Primary Action (`#166B87`):** Petrol Blue serves as the main interactive driver, reserved for key actions, active links, primary buttons, and selected states.
- **Deep Marine (`#13283F`):** Anchors high-contrast headings, KPI numbers, and prominent structural chrome.
- **Soft Teal Tint (`#EAF4F6`):** Provides subtle emphasis for active navigation states, selected card containers, and data callout backgrounds.
- **Canvas Base (`#F8FAFB`):** A soft, eye-resting off-white neutral base that prevents eye strain across long working sessions.
- **Card Surfaces (`#FFFFFF`):** High-clarity white for modular cards, tables, and dialog surfaces.

### Semantic Color Engine
- **Income / Paid (`#1B8755`):** Positive cash inflows, confirmed settlements, and successful reconciliations. Soft surface: `#E8F5EE`.
- **Expense / Pending (`#D9383A`):** Outflows, critical debt liabilities, and pending payments. Soft surface: `#FDECEC`.
- **Overdue / Alert (`#B87A00`):** Overdue bills, operational warnings, and delayed approvals. Soft surface: `#FFF6E5`.
- **Neutral Boundaries (`#E2E8F0`):** Fine lines for cards, cell dividers, and inputs.

## Typography

The typography uses **Manrope**, offering balanced geometry, neutral metrics, and distinct tabular numerals essential for financial ledgers.

- Headings and numeric summaries utilize weights `600` and `700` in `#13283F` to maintain distinct hierarchy against lighter data grids.
- Financial monetary values always render with proportional tabular figures (`tnum`) to align decimals accurately across ledger columns.
- Microcopy, table headers, and badges use uppercase or compact tracking (`0.01em` - `0.02em`) with weight `600` to anchor scanning patterns without dominating page density.

## Layout & Spacing

The layout is constructed on an 8pt spatial grid with an underlying 12-column responsive layout engine for wide desktop workstations, collapsing to 8 columns on tablets and 4 columns on mobile viewports.

- **Desktop (>= 1200px):** 12 columns, 24px gutters, fixed or fluid sidebars with 32px canvas margins.
- **Tablet (768px - 1199px):** 8 columns, 16px gutters, collapsible side drawer, 20px margins.
- **Mobile (< 768px):** 4 columns, 12px gutters, 16px margins, stacking financial ledger lists into vertical card formats.

## Elevation & Depth

Visual hierarchy uses a refined hybrid approach: crisp, single-pixel borders (`#E2E8F0`) combined with faint, tinted ambient shadows. This prevents heavy visual noise in analytical views while providing structural separation.

- **Flat Baseline (Canvas):** `#F8FAFB` with zero elevation.
- **Card Tier 1 (Resting Cards, Table Containers):** `#FFFFFF` surface, `1px solid #E2E8F0`, ambient shadow `0 1px 3px rgba(19, 40, 63, 0.04), 0 1px 2px rgba(19, 40, 63, 0.02)`.
- **Card Tier 2 (Hovered Cards, Dropdown Panels, Popovers):** `#FFFFFF` surface, `1px solid #CBD5E1`, elevated shadow `0 4px 12px rgba(19, 40, 63, 0.08)`.
- **Overlay Tier (Modals, Transaction Sliders):** `#FFFFFF`, modal backdrop `rgba(19, 40, 63, 0.45)`, shadow `0 12px 32px rgba(19, 40, 63, 0.16)`.

## Shapes

The design system adopts a **Soft (Level 1)** corner curvature. This reinforces a structured, institutional, and precise demeanor fitting for enterprise finance.

- Basic controls, badges, inputs, and buttons carry `0.25rem` (4px) to `0.375rem` (6px) curvature.
- Content cards, modals, and panel sheets use `rounded-lg` (`0.5rem` / 8px).
- Badges and pill tags use subtle rounded boundaries rather than playful stadium pills, maintaining an organized balance.

## Components

### Buttons
- **Primary:** Background `#166B87`, text `#FFFFFF`, hover `#12546A`. Height 40px (desktop), 36px (compact). Padding: `0.5rem 1rem`.
- **Secondary:** Surface `#FFFFFF`, border `1px solid #166B87`, text `#166B87`, hover `#EAF4F6`.
- **Ghost / Tertiary:** Transparent surface, text `#13283F`, hover `#F1F5F9`.
- **Destructive:** Background `#D9383A`, text `#FFFFFF`, hover `#B8282A`.

### Status Badges (Mandatory Text & Icon)
Every badge must contain an icon alongside its textual state to ensure rapid recognition and accessibility compliance:
- **Paid / Received:** Background `#E8F5EE`, text `#1B8755`, icon `CheckCircle` (14px).
- **Pending / Expense:** Background `#FDECEC`, text `#D9383A`, icon `Clock` or `ArrowDownRight` (14px).
- **Overdue:** Background `#FFF6E5`, text `#B87A00`, icon `AlertTriangle` (14px).
- Padding: `2px 8px`, border radius: `4px`, font: `label-sm`.

### Form Inputs & Selects
- Height 40px, background `#FFFFFF`, border `1px solid #CBD5E1`, text `#13283F`.
- Focus state: `1px solid #166B87` with an ambient ring `0 0 0 3px rgba(22, 107, 135, 0.15)`.
- Helper labels: `#64748B`, weight `600`, size `12px`.

### Cards & Ledger Tables
- **Cards:** Pure white surface (`#FFFFFF`), `1px solid #E2E8F0`, padding `1.5rem` (`space-lg`).
- **Data Tables:** Row height 48px, horizontal borders only (`1px solid #EDF2F7`), header row `#F8FAFB` with text `#64748B` in `label-sm`. Hover on rows: `#F8FAFC`.
- **KPI Summary Cards:** Top or left visual accent using semantic tokens (`#1B8755`, `#D9383A`, `#166B87`) with high-contrast marine typography for values.

### Checkboxes & Radios
- Size 16x16px, border `1px solid #94A3B8`, active fill `#166B87` with crisp white checkmark or center dot.